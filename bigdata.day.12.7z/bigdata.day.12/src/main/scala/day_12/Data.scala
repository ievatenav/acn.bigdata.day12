package day_12

import org.apache.log4j.{Level, LogManager, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import day_12.Time.time

object Data {
  def main(args: Array[String]){
    val conf = new SparkConf().setAppName("Sample App").setMaster("local")
    val sc = new SparkContext(conf)
    println("Hello world!")

    val csv = sc.textFile("src/SacramentocrimeJanuary2006.csv")  // original file
    val data = csv.map(line => line.split(",").map(elem => elem.trim)) //lines in rows
    val header = new header(data.take(1)(0)) // we build our header with the first line
    val rows = data.filter(line => header(line,"cdatetime") != "cdatetime") // filter the header out
    //rows.map(t => t.toList).foreach(println)

    val tsv = sc.textFile("src/ucr_ncic_codes.tsv")  // original file
    val data1 = tsv.map(line => line.split("\\t+").map(elem => elem.trim)) //lines in rows
    val header1 = new header(data1.take(1)(0)) // we build our header with the first line
    val rows1 = data1.filter(line => header1(line,"Crime Code") != "Crime Code") // filter the header out
   // rows1.map(t => t.toList).foreach(println)



    // Task 1
    val district = rows
      .map(row => header(row,"district"))
      .map(t => t.toString)
      .distinct.sortBy(x => x, true)
    //district.foreach(println)

    // Task 2
    val crime_count = rows
        .map(t => (t(2), 1))
        .reduceByKey(_ + _)
        .max()(Ordering[Int].on(x=>x._2))
        //println(crime_count)


    // Task 3
    val time = rows
        .map(row => header(row,"cdatetime"))
        .map(t => t.toString)
        .map(t => t.split(" "))
        .map(t => t(1))
        .map(t => t.slice(0, t.length - 3))
        .map(t => t.toInt)
        .groupBy(t => (t >= 6 && t < 12, t >= 12 && t < 18, t >= 18 && t < 0, t >= 0 && t < 6))
        .map(t => t._2.toList.length)
        .max
    println("Day " + time)


    // Task 5
    val crimes_per_day = rows
      .map(row => header(row,"cdatetime"))
      .map(t => t.toString)
      .map(t => t.split(" "))
      .map(t => (t(0), 1))
      .reduceByKey(_ + _)
    //crimes_per_day.foreach(println)

    //Task 7
    val code = rows
      .map(t => t(2))

    val cat = rows1
        .map(t => (t(0), t(1)))
      //.reduceByKey(_ + _)
      //.max()(Ordering[Int].on(x=>x._2))
    //top5.foreach(println)

    println("Done!")
  }

  protected val logger: Logger = {
    val l = LogManager.getRootLogger
    l.setLevel(Level.DEBUG)

    val org = LogManager.getLogger("org")
    org.setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    l
  }
}